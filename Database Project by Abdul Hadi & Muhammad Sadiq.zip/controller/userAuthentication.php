<?php
include_once("connection.php");

//NEW CODE STARTS HERE
if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    if(!isset($_POST['email']) or !isset($_POST['password']))
    {
        echo "Login failed";
    }else{
        if($_POST['email']=="ADMIN" && $_POST['password']=="@DMINP@$$"){
            session_start();
            $_SESSION['reADyaiLOGp@S'] = "@DMINP@$$";
            echo "success";
            $_SESSION['accountName']= "Administrator";
        }else{
            $loginEmail = htmlspecialchars(trim($_POST["email"]));
            $loginPass = htmlspecialchars(trim($_POST["password"]));
            $loginStatus = 0;

            $stmt = $conn->prepare("SELECT * FROM user_accounts WHERE email = ? AND password = ? AND status = ?");
            $stmt->bind_param("ssi", $loginEmail, $loginPass, $loginStatus);
            $stmt->execute();
            $result = $stmt->get_result();

            //getting name of the user:
            $stmt2 = $conn->prepare("SELECT full_name FROM user_accounts WHERE email = ? AND password = ?");
            $stmt2->bind_param("ss", $loginEmail, $loginPass);
            $stmt2->execute();
            $nameOfUser = $stmt2->get_result();

            if($result->num_rows === 0)
            {
                echo "Only registered and verified teachers can login (please contact ReadyAI management for account varification).";
                // header("location: ../account/login.php?error=true");
            } else {
                session_start();
                // $_SESSION['loginKey'] = 'InLogedAccount';
                $_SESSION['reADyaiLOGp@S'] = $loginEmail;
                // header("location: ../index.php");
                echo "success";

            }
            if($nameOfUser->num_rows > 0 ){
                while($row = $nameOfUser->fetch_assoc()){
                    // echo $row['fullname'];
                    $_SESSION['accountName']= $row['full_name'];     
                }
            }
            $stmt->close();
            $stmt2->close();
        }
    }
} else {
    echo "Something went wrong. Please try again.";
}