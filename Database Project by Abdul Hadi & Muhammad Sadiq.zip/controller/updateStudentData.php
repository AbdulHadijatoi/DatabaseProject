<?php

include_once("connection.php");
// i - integer | d - double  |  s - string  |  b - BLOB

if($_SERVER["REQUEST_METHOD"] == "POST") {
                                                
    if(isset($_POST['id'],$_POST['fullname'], $_POST['qualification'], $_POST['training_date'], $_POST['affiliation'], $_POST['tid'], $_POST['gender'])){
		
        $userid = htmlspecialchars(trim($_POST["id"]));
        $teacherid = htmlspecialchars(trim($_POST["tid"]));
        $stmt1 = $conn->prepare("SELECT * FROM student_accounts WHERE sid = ? AND tid = ?");
		$stmt1->bind_param("ii", $userid, $teacherid);
		$stmt1->execute();
		$result = $stmt1->get_result();
        $stmt1->close();
		if($result->num_rows > 0){

            $student_name = htmlspecialchars(trim($_POST['fullname']));
            $qualification = htmlspecialchars(trim($_POST['qualification']));
            $training_date = htmlspecialchars(trim($_POST['training_date']));
            $affiliation = htmlspecialchars(trim($_POST['affiliation']));
            // $gender = htmlspecialchars(trim($_POST['gender']));
            $gender = htmlspecialchars(trim($_POST['gender']));
            $sid = htmlspecialchars(trim($_POST['id']));
            $tid = htmlspecialchars(trim($_POST['tid']));

            if( strlen($_POST['trainingsattended']) > 0 ){
                $trainingsattended = htmlspecialchars(trim($_POST['trainingsattended']));
            }else{
                $trainingsattended = "No training attended yet!";
            }




            //File Code
            $target_dir = "../images/students/";
            $target_file = $target_dir . basename($_FILES["photo"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            // Check if image file is a actual image or fake image
            $file = $_FILES["photo"]["tmp_name"];
            if (isset($file)){
                $check = getimagesize($file);
                if($check !== false) {
                    // echo "File is an image - " . $check["mime"] . ".";
                    $photo = $target_file;
                    $uploadOk = 1;
                    

                    if (move_uploaded_file($file, $target_file)) {
                        echo "The file ". basename($file). " has been uploaded.";
                    } else {
                        echo "Sorry, there was an error uploading your file.";
                    }


                }
            }
             else {
                $photo = "../images/students/default-icon.png";
                $uploadOk = 0;
            }

            //File Code ends...
            





            // else{
            //     $photo = "../images/students/default-icon.png";
            //     echo $photo;
            // }

            if( strlen($_POST['levelofexpertise']) > 0){
                $levelofexpertise = htmlspecialchars(trim($_POST['levelofexpertise']));
            }else{
                $levelofexpertise = "No expertise yet!";
            }

            if( strlen($_POST['description']) > 0){
                $description = htmlspecialchars(trim($_POST['description']));
            }else{
                $description = "No description added.";
            }
            echo $photo;
        }
        
    }else{
        echo "Some fields might be empty.";
    }
} else {
    echo "Something went wrong. Please try again.";
}