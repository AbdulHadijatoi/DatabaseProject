<?php

include_once("connection.php");

// i - integer | d - double  |  s - string  |  b - BLOB
// Name Designation Email Password
// set parameters and execute

// $userExist = false;
if(isset($_POST['studentName'], $_POST['qualification'], $_POST['trainingDate'], $_POST['affiliation'], $_POST['levelOfExpertise'], $_POST['noOfTraining'])){


	// $photo
	// 		$studentName
	// 		$qualification
	// 		$trainingDate
	// 		$affiliation
	// 		$levelOfExpertise
	// 		$noOfTraining

	

	//will setup hidden variable for tid, inside html file later
	$tid = $_POST['tid'];

	$loggedEmail = $_POST['email'];

	$stmt = $conn->prepare("SELECT * FROM Student_Accounts WHERE tid = ?");
	$stmt->bind_param("s", $tid);
	$stmt->execute();
	$result = $stmt->get_result();

	if($result->num_rows > 0){
		while($row = $result->fetch_assoc()){
			$sid = $row['sid'];	
			$photo = $row['photo'];
			$studentName = $row['studentname'];
			$qualification = $row['qualification'];
			$trainingDate = $row['trainingdate'];
			$affiliation = $row['affiliation'];
			$levelOfExpertise = $row['levelofexpertise'];
			$noOfTraining = $row['nooftrainingattanded'];
		}
	}

	$stmt = $conn->prepare("INSERT INTO user_accounts (full_name, designation, email, password) VALUES (?, ?, ?, ?)");
	if($tid != 0)
	if(isset($_POST['photo'])){
		$stmt->bind_param("ssssssii", $photo, $studentName, $qualification, $trainingDate, $affiliation, $levelOfExpertise, $noOfTraining, $tid);
	}else{
		$stmt->bind_param("ssssssii", $defaultPhoto, $studentName, $qualification, $trainingDate, $affiliation, $levelOfExpertise, $noOfTraining, $tid);
	}
	
	$stmt->execute();

	// echo "New records created successfully";
	$stmt->close();
	// $conn->close();
    
}
else{
    echo "No record found!";
}
