<?php
    //Creating database connection to use throughout the project.
    $user = 'root';
    $pass = '';
    $serverName = 'localhost';
    $dbName = 'readyai';

    // Creating connection
    $conn = new mysqli($serverName, $user, $pass, $dbName);

    // Checking connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    // echo "Connection successfull!";
 
?>