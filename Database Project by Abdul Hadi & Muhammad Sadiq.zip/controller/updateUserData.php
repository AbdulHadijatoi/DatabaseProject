<?php

include_once("connection.php");
// i - integer | d - double  |  s - string  |  b - BLOB
//NEW CODE STARTS HERE
if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // $userID = $row["id"];
    // $userName = $row["full_name"];
    // $userDisgnation = $row["designation"];
    // $userEmail = $row["email"];
    // $userPass = $row["password"];
    // $userPhoto = $row["photo"];
    // $userSpecialization = $row["specialization"];
    // $userInterests = $row["interests"];
    // $userPhone = $row["phone"];
    // $userNationality = $row["nationality"];
    // $userInstitute = $row["institute"];
    // $userDescription = $row["description"];
    // $userStatus = $row['status'];

    
    // var fullname = document.getElementById("fullname");
    // var designation = document.getElementById("designation");
    // var email = document.getElementById("email");
    // var password = document.getElementById("password");
    // var specialization = document.getElementById("specialization");
    
    //fields names:
    // id fullname designation email password 
    // photo specialization interests phone nationality institute description status

    // echo $_POST['id'];
    
    if(isset($_POST['id'],$_POST['fullname'], $_POST['designation'], $_POST['email'], $_POST['password'])){
		
		$userid = htmlspecialchars(trim($_POST["id"]));
        $stmt1 = $conn->prepare("SELECT * FROM user_accounts WHERE id = ?");
		$stmt1->bind_param("i", $userid);
		$stmt1->execute();
		$result = $stmt1->get_result();
        $stmt1->close();
		if($result->num_rows > 0){
            $fullname = htmlspecialchars(trim($_POST['fullname']));
			$designation = htmlspecialchars(trim($_POST['designation']));
			$email = htmlspecialchars(trim($_POST['email']));
            $specialization = htmlspecialchars(trim($_POST['specialization']));
            $password = htmlspecialchars(trim($_POST['password']));

            if( isset($_POST['interests'])){
                $interests = htmlspecialchars(trim($_POST['interests']));
            }else{
                $interests = "No interest added!";
            }

            if( isset($_POST['photo'])){
                $photo = htmlspecialchars(trim($_POST['photo']));
            }else{
                $photo = "../images/students/default-icon.png";
            }

            if( isset($_POST['phone'])){
                $phone = htmlspecialchars(trim($_POST['phone']));
            }else{
                $phone = "0000 0000 0000";
            }

            if( isset($_POST['nationality'])){
                $nationality = htmlspecialchars(trim($_POST['nationality']));
            }else{
                $nationality = "No nationality added.";
            }

            if( isset($_POST['institute'])){
                $institute = htmlspecialchars(trim($_POST['institute']));
            }else{
                $institute = "No institute added yet.";
            }

            if( isset($_POST['description'])){
                $description = htmlspecialchars(trim($_POST['description']));
            }else{
                $description = "No description is added.";
            }

            if( isset($_POST['status'])){
                $status = htmlspecialchars(trim($_POST['status']));
            }else{
                $status = 1;
            }

            $id = $_POST['id'];
    
            $stmt2 = $conn->prepare("
                UPDATE user_accounts 
                SET full_name=?, 
                    designation=?, 
                    email=?, 
                    password=?, 
                    photo=?, 
                    specialization=?, 
                    interests=?, 
                    phone=?, 
                    nationality=?, 
                    institute=?, 
                    description=?, 
                    status=? 
                WHERE id=?"
            );
            $stmt2->bind_param("sssssssssssii", 
                $fullname, 
                $designation, 
                $email, 
                $password, 
                $photo, 
                $specialization, 
                $interests, 
                $phone, 
                $nationality, 
                $institute, 
                $description, 
                $status, 
                $id
            );

            $stmt2->execute();
            
            if ( $stmt2->affected_rows < 0 ) {
                echo "No record was updated!";
            }else{
                echo "Successfully updated..";
            }
            
            $stmt2->close();
        }
        
    }else{
        echo "Some fields might be empty.";
    }
} else {
    echo "Something went wrong. Please try again.";
}