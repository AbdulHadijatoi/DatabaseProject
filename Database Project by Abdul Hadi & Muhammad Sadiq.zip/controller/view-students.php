<?php

    include_once("connection.php");
    // error_reporting(0);
    
    //Table Column names:
    // tid
    // sid
    // photo
    // student_name
    // qualification
    // training_date
    // affiliation
    // levelofexpertise
    // nooftrainingattanded
    // description
    // login_id
    // login_pass
    // gender

    $stmt1 = "SELECT * FROM student_accounts"; 
    if ($res = $conn->query($stmt1)) { 
        if ($res->num_rows > 0) { 
            while ($row = $res->fetch_array())  
            { 
                $tid = $row["tid"];
                $sid = $row["sid"];
                $photo = $row["photo"];
                $student_name = $row["student_name"];
                $qualification = $row["qualification"];
                $training_date = $row["training_date"];
                $affiliation = $row["affiliation"];
                $levelofexpertise = $row["levelofexpertise"];
                $nooftrainingattanded = $row["nooftrainingattanded"];
                $description = $row["description"];
                // $userInstitute = $row["login_id"];
                // $userDescription = $row["login_pass"];
                $gender = $row['gender'];

                echo <<<EOT
                    <tr>
                    <td>$sid</td>
                    <td>$student_name</td>
                    <td>$qualification</td>
                    <td>$training_date</td>
                    <td>$affiliation</td>
                    <td>$gender</td>
                    <td>$tid</td>
                EOT;
          
                echo <<< EOT
                        <td>
                            <div class="btn-group" role="group">
                                <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="View">
                                    <i class="mdi mdi-eye"></i>
                                </button>
                                <button href="#editRecord" type="button" class="popup-form btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="Edit"
                                onclick=" 
                                document.getElementById('id').value = '$sid';
                                document.getElementById('fullname').value = '$student_name';
                                document.getElementById('qualification').value = '$qualification';
                                document.getElementById('training_date').value = '$training_date';
                                document.getElementById('affiliation').value = '$affiliation';
                    EOT;

                if($gender == "Male"){
                    echo <<< EOT
                            document.getElementById('male').checked = true;
                            EOT;
                }else{
                    echo <<< EOT
                            document.getElementById('female').checked = true;
                            EOT;
                }
                
                echo <<< EOT
                                document.getElementById('tid').value = '$tid';
                                document.getElementById('trainingsattended').value = '$nooftrainingattanded';
                                document.getElementById('photo').value = '$photo';
                        EOT;

                if($levelofexpertise == 'Beginner'){
                    echo <<< EOT
                        document.getElementById('levelofexpertise').options[0].selected = 'true';
                        EOT;
                }else if($levelofexpertise == 'Intermediate'){
                    echo <<< EOT
                        document.getElementById('levelofexpertise').options[1].selected = 'true';
                        EOT;
                } else if($levelofexpertise == 'Expert'){
                    echo <<< EOT
                        document.getElementById('levelofexpertise').options[2].selected = 'true';
                        EOT;
                }

                echo <<< EOT
                                document.getElementById('description').value = '$description';"
                                >
                                    <i class="mdi mdi-pencil"></i>
                                </button>
                                <button type="button" class="btn btn-outline-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="Delete">
                                    <i class="mdi mdi-trash-can"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    EOT;
                    
                    
            }    
            $res->free(); 
            
        }else { 
            // echo "No matching records are found."; 
        } 
        
    }else{ 
        // echo "ERROR: Could not able to execute $sql. ".$mysqli->error; 
    }
    // $stmt1->close();