<?php

include_once("connection.php");
// i - integer | d - double  |  s - string  |  b - BLOB
//NEW CODE STARTS HERE
if($_SERVER["REQUEST_METHOD"] == "POST") {
    
    if(isset($_POST['name'], $_POST['designation'], $_POST['email'], $_POST['password'], $_POST['tSecKey_123'])){
		
		$loginEmail = htmlspecialchars(trim($_POST["email"]));
        $stmt = $conn->prepare("SELECT * FROM user_accounts WHERE email = ?");
		$stmt->bind_param("s", $loginEmail);
		$stmt->execute();
		$result = $stmt->get_result();

		if($result->num_rows > 0){
			//user already exists, don't create record
			echo "Email already registered, please try again.";
			// header("location: ../account/signup.php?error=true");
		} else {
			$fullname = htmlspecialchars(trim($_POST['name']));
			$designation = htmlspecialchars(trim($_POST['designation']));
			$email = htmlspecialchars(trim($_POST['email']));
			$password = htmlspecialchars(trim($_POST['password']));
			$tSecKey_123 = htmlspecialchars(trim($_POST['tSecKey_123']));
	
			$stmt = $conn->prepare("INSERT INTO user_accounts (full_name, designation, email, password) VALUES (?, ?, ?, ?)");
			$stmt->bind_param("ssss", $fullname, $designation, $email, $password);
			$stmt->execute();
			
			if ( $stmt === false ) {
				echo "Something went wrong. Please try again.";
			}else{
				echo "Successfully registered";
				unset($_POST['tSecKey_123']);
			}
			// echo "New records created successfully";
			$stmt->close();
			// $conn->close();
		}
    }
} else {
    echo "Something went wrong. Please try again.";
}