<?php
include_once("connection.php");
	$full_name = "";
	$designation = "";
	$email = "";
	$password = "";
	$photo = "";
	$description = "";
	$specialization = "";
	$interests = "";
	$phone = "";
	$nationality = "";
	$institute = "";

	// $sid = "";
	// $qualification = "";
	// $training_date = "";
	// $affiliation = "";
	// $levelofexpertise = "";
	// $nooftrainingattanded = "";
	// $student_name = "";
	// $gender = "";

	$userData = array();

	
	if(!empty($_GET['id'])){
		$urlID = (int)htmlspecialchars(trim($_GET['id']));
		
		$stmt2 = $conn->prepare("SELECT * FROM student_accounts WHERE sid = ?");

		// echo "<pre>";
		// var_dump($stmt2);
		// echo "</pre>";

		$stmt2->bind_param("i", $urlID);

		// echo "<pre>";
		// var_dump($stmt2);
		// echo "</pre>";

		$stmt2->execute();
		$result = $stmt2->get_result();

		// var_dump($result);
		// exit;

		if($result->num_rows > 0)
		{
			while ($row = $result->fetch_assoc())     
			{
				//Students' Records
				$userData['sid'] = $row['sid'];
				$userData['photo'] = $row['photo'];
				$userData['qualification'] = $row['qualification'];
				$userData['training_date'] = $row['training_date'];
				$userData['affiliation'] = $row['affiliation'];
				$userData['levelofexpertise'] = $row['levelofexpertise'];
				$userData['nooftrainingattanded'] = $row['nooftrainingattanded'];
				$userData['student_name'] = $row['student_name'];
				$userData['description'] = $row['description'];
				$userData['gender'] = $row['gender'];
			}
		}

		// var_dump($userData);
		// exit;

		$stmt2->close();
	}
	


	if(isset($_GET['email'])){
		$urlEmail = htmlspecialchars(trim($_GET['email']));
		if($urlEmail != ""){
			$stmt1 = $conn->prepare("SELECT * FROM user_accounts WHERE email = ?");
			$stmt1->bind_param("s", $urlEmail);
			$stmt1->execute();
			$result = $stmt1->get_result();
			if($result->num_rows > 0)
			while ($row = $result->fetch_assoc()){       
				//Teachers Records
				$full_name = $row['full_name'];
				$designation = $row['designation'];
				$email = $row['email'];
				$password = $row['password'];
				
				if($row['specialization'] ==""){
					$specialization = 'Specialization not added yet!';
				}else{
					$specialization = $row['specialization'];
				}

				if($row['photo'] ==""){
					$photo = 'Photo not added yet!';
				}else{
					$photo = $row['Photo'];
				}

				if($row['description'] ==""){
					$description = 'Description not added yet!';
				}else{
					$description = $row['description'];
				}

				if($row['interests'] ==""){
					$interests = 'Interests not added yet!';
				}else{
					$interests = $row['interests'];
				}

				if($row['phone'] ==""){
					$phone = 'Number not added yet!';
				}else{
					$phone = $row['phone'];
				}

				if($row['nationality'] ==""){
					$nationality = 'Nationality not added yet!';
				}else{
					$nationality = $row['nationality'];
				}

				if($row['nationality'] ==""){
					$institute = 'Institute not added yet!';
				}else{
					$institute = $row['institute'];
				}
				
			}
			$stmt1->close();
		}
	}