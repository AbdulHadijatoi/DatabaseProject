<?php
    include_once("connection.php");
    $logged_time = time() - 6;
    $stmt1 = "SELECT * FROM user_accounts"; 
    if ($res = $conn->query($stmt1)) { 
        if ($res->num_rows > 0) { 
            while ($row = $res->fetch_array()){ 
                $user_name = $row["user_name"];
                $user_ip = $row["user_ip"];
                $log_time = $row["log_time"];
                $user_status = "";
                if($row['logged'] > $logged_time) {
                    $user_status = "online";
                }else{
                    $user_status = "offline";
                }
                $stmt2 = $conn->prepare("
                    UPDATE user_accounts 
                    SET user_status = ?
                    WHERE user_id=?"
                );
                $stmt2->bind_param("si", $user_status, $row['user_id']);
                $stmt2->execute();
                echo <<< EOT
                    <tr>
                    <th scope="row">$user_name</th>
                    <td>$user_ip</td>
                    <td>$log_time</td>
                    <td class='user-status'>
                    $user_status</td>
                    </tr>
                EOT;
            }    
            $res->free(); 
            $stmt2->close();
        }
    }