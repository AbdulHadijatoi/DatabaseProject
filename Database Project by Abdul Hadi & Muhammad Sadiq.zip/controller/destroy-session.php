<?php
    session_destroy();
    echo "session-destroyed";
