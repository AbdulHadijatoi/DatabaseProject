<?php
include_once("connection.php");
error_reporting(0);
if($_SERVER["REQUEST_METHOD"] == "POST") {
	
	$photo = "";

	if(isset($_POST['photo'])){
		$photo = htmlspecialchars(trim($_POST['photo']));
	}
	$defaultPhoto = "../images/students/default-icon.png";
	$studentName = htmlspecialchars(trim($_POST['studentName']));
	$qualification = htmlspecialchars(trim($_POST['qualification']));
	$trainingDate = date("Y-d-m", strtotime(htmlspecialchars(trim($_POST['trainingDate']))));
	$affiliation = htmlspecialchars(trim($_POST['affiliation']));
	$levelOfExpertise = htmlspecialchars(trim($_POST['levelOfExpertise']));
	$noOfTraining = htmlspecialchars(trim($_POST['noOfTraining']));
	$gender = htmlspecialchars(trim($_POST['gender']));
	
	if(session_id() == ''){
		session_start();
	}

	$loggedEmail = $_SESSION['reADyaiLOGp@S'];
	$tid = 0;

    // if((isset($_POST['studentName'], $_POST['qualification'], $_POST['trainingDate'], $_POST['affiliation'], $_POST['levelOfExpertise'], $_POST['noOfTraining']))){
	if( strlen($gender) > 0 && strlen($studentName) > 0 && strlen($qualification) > 0 && strlen($affiliation) > 0 && strlen($levelOfExpertise) > 0 && strlen($loggedEmail) > 0 && strlen($trainingDate) > 0 && $noOfTraining>0 ){

		$stmt1 = $conn->prepare("SELECT id FROM user_accounts WHERE email = ?");
		$stmt1->bind_param("s", $loggedEmail);
		$stmt1->execute();
		$result = $stmt1->get_result();

		if($result->num_rows > 0){
			while($row = $result->fetch_assoc()){
				$tid = $row['id'];	
			}
		}

		$stmt1->close();

		//Checking existing enrolled record starts 
		// username = $uName AND password = $pWord";
		$stmt3 = $conn->prepare("SELECT * FROM student_accounts WHERE tid = ? AND qualification = ? AND training_date = ? AND levelofexpertise = ? AND nooftrainingattanded = ? AND student_name = ? AND gender = ? ");
		$stmt3->bind_param("isssiss", $tid, $qualification, $trainingDate, $levelOfExpertise, $noOfTraining, $studentName, $gender);
		$stmt3->execute();
		$result = $stmt3->get_result();

		if($tid != 0)
		if($result->num_rows > 0){
			echo "This student is already enrolled!"; 
		}else{
			// $tr_date = "STR_TO_DATE({$trainingDate}, '%y-%m-%d')";
			$stmt2 = $conn->prepare("INSERT INTO `student_accounts`(`tid`, `photo`, `qualification`, `training_date`, `Affiliation`, `levelofexpertise`, `nooftrainingattanded`, `student_name`, `gender`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
			if(isset($_POST['photo'])){
				$stmt2->bind_param("isssssiss", $tid, $photo, $qualification, $trainingDate, $affiliation, $levelOfExpertise, $noOfTraining, $studentName, $gender);
			}else{
				$stmt2->bind_param("isssssiss", $tid, $defaultPhoto, $qualification, $trainingDate, $affiliation, $levelOfExpertise, $noOfTraining, $studentName, $gender);
			}
				
			$stmt2->execute();

			if ( !$stmt2 )
				echo "Something went wrong. Please try again.";
			else{
				echo "Successfully enrolled";
			}

			$stmt2->close();
		}
		$stmt3->close();
		//Checking existing enrolled record ends
    }else{
		echo "Please make sure you have input all the fields correctly.";
	}
} else {
    echo "Something went wrong. Please try again.";
}