
<?php
    include_once("../controller/profile.php");
    error_reporting(0);


		// var_dump($userData);
		// exit;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?php 
                if(isset($_GET['email'])){
                    echo $full_name;
                }else{
                    echo $userData['student_name'];
                }   
            ?> | ReadyAi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A premium personal template by Mannatthemes" name="description" />
    <meta content="Mannatthemes" name="author" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="images/favicon.ico">

    <link href="plugins/filter/magnific-popup.css" rel="stylesheet" type="text/css" />
    <link href="plugins/animated/headline.css" rel="stylesheet" type="text/css" />

    <!-- App css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="css/icons.css" rel="stylesheet" type="text/css" />
    <link href="css/style.css" rel="stylesheet" type="text/css" />

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-navbar">
        <div class="container">
            <a class="navbar-brand" href="../index.php"></i>ReadyAi</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav" aria-controls="nav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
            </button>
            <!--end navbar-toggler-->

            <div class="collapse navbar-collapse" id="nav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="btn btn-blue btn-sm px-4" href="#" id="lnkPrint"><i class="'uil uil-print mr-1 font-16"></i>Print/Save Profile</a>
                    </li>
                </ul>
            </div>
            <!--end collapse-->
        </div>
        <!--end container-->
    </nav>
    <!--end nav-->

    <div class="main-wraper">
        <section class="section bg-profile" id="profile_ripple">
            <div class="zoo-profile">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-print-6 align-self-center mb-3 mb-lg-0">
                            <div class="zoo-profile-main">
                                <div class="zoo-profile-main-pic">
                                    <img src="../images/default-icon.png" width="100px" alt="" class="rounded-circle">
                                </div>
                                <!--end zoo-profile-main-pic-->
                                <div class="zoo-profile_user-detail">
                                    <h5 class="zoo-user-name">
                                    <?php 
                                        
                                        if(isset($_GET['email'])){
                                            echo $full_name;
                                        }else{
                                            echo $userData['student_name'];
                                        }
                                    ?>
                                    </h5>
                                    <p class="cd-headline loading-bar">
                                        <span class="cd-words-wrapper">
                                                <b class="is-visible">
                                                <?php
                                                    if(isset($_GET['email'])){
                                                        echo $designation;
                                                    }else{
                                                        echo $userData['qualification'];
                                                    }
                                                ?>
                                                </b>
                                                
                                                <b>
                                                <?php 
                                                    //Second Tag
                                                    if(isset($_GET['email'])){
                                                        echo $designation;
                                                    }else{
                                                        echo $userData['qualification'];
                                                    }
                                                ?></b>
                                            </span>
                                    </p>
                                </div>
                                <!--end zoo-profile_user-detail-->
                            </div>
                            <!--end profile-main-pic-->
                        </div>
                        <!--end col-->
                        <div class="col-sm-4 col-print-4 ml-auto">
                            <ul class="list-unstyled personal-detail">
                                <li><i id="phoneIcon" class="'uil uil-phone-volume mr-2"></i> <b id="phoneField"> Phone </b> : 
                                <?php
                                                    if(isset($_GET['email'])){
                                                        echo $phone;
                                                    }else{
                                                        echo <<< EOT
                                                            <script>
                                                                document.getElementById('phoneField').innerHTML = 'Training Date';
                                                                document.getElementById('phoneIcon').style.visibility = 'hidden';
                                                            </script>
                                                            EOT;
                                                        echo $userData['training_date'];
                                                    }
                                ?>
                                </li>
                                <li class="mt-2"><i id="emailIcon" class="uil uil-envelope mt-2 mr-2"></i> <b id="emailField"> Email </b> : 
                                <?php
                                    if(isset($_GET['email'])){
                                        echo $email;
                                    }else{
                                        echo <<< EOT
                                            <script>
                                                document.getElementById('emailField').innerHTML = 'Affiliation';
                                                document.getElementById('emailIcon').style.visibility = 'hidden';
                                            </script>
                                            EOT;
                                        echo $userData['affiliation'];
                                    }
                                ?>
                                </li>
                            </ul>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->
                </div>
                <!--end container-->
            </div>
            <!--end zoo-profile-->
        </section>
        <!--end section-->

        <section class="section-md">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h4 class="header-title mb-3">About me!</h4>
                    </div>
                    <!--end col-->
                    <div class="col-sm-6 col-print-6">
                        <h4 class="text-primary font-weight-bold">I'm 
                        <?php
                            if(isset($_GET['email'])){
                                echo $full_name;
                            }else{
                                echo $userData['student_name'];
                            }
                        ?>
                        </h4>

                        <p>
                            <?php
                                if(isset($_GET['email'])){
                                    echo $description;
                                }else{
                                    echo $userData['description'];
                                }
                            ?>
                        </p>
                    </div>
                    <!--end col-->
                    <div class="col-sm-5 col-print-5 offset-lg-1 align-self-center">
                        <p>
                            <span class="personal-detail-title">Name</span>
                            <span class="personal-detail-info">
                            <?php
                                if(isset($_GET['email'])){
                                    echo $full_name;
                                }else{
                                    echo $userData['student_name'];
                                }
                            ?>
                            </span>
                        </p>
                        <p>
                            <span class="personal-detail-title" id="speciField">Specialization</span>
                            <span class="personal-detail-info">
                                <?php
                                    if(isset($_GET['email'])){
                                        echo $specialization;
                                    }else{
                                        echo <<< EOT
                                                <script>document.getElementById('speciField').innerHTML = 'Trainings Count';</script>
                                                EOT;
                                        echo $userData['nooftrainingattanded'];
                                    }
                                ?>
                            </span>
                        </p>
                        <p>
                            <span class="personal-detail-title" id="instituteField">Institute</span>
                            <span class="personal-detail-info">
                            <?php echo $institute?>
                            <?php
                                    if(isset($_GET['email'])){
                                        echo $institute;
                                    }else{
                                        echo <<< EOT
                                                <script>document.getElementById('instituteField').innerHTML = 'Level of Expertise';</script>
                                                EOT;
                                        echo $userData['levelofexpertise'];
                                    }
                                ?>
                            </span>
                        </p>
                        <p>
                            <span class="personal-detail-title" id="nationalityField">Nationality</span>
                            <span class="personal-detail-info">
                            <?php 
                                if(isset($_GET['email'])){
                                    echo $nationality;
                                }else{
                                    echo <<< EOT
                                            <script>document.getElementById('nationalityField').innerHTML = 'Gender';</script>
                                            EOT;
                                    echo $userData['gender'];
                                }
                            
                            ?>
                            </span>
                        </p>
                        <p>
                            <span class="personal-detail-title" id="interestField">Interest</span>
                            <span class="personal-detail-info">
                            <?php 
                                if(isset($_GET['email'])){
                                    echo $interests;
                                }else{
                                    echo <<< EOT
                                            <script>document.getElementById('interestField').innerHTML = 'Qualification';</script>
                                            EOT;
                                    echo $userData['qualification'];
                                }
                            ?>
                            </span>
                        </p>
                    </div>
                    <!--end col-->
                </div>
                <!--end row-->
            </div>
            <!--end container-->
        </section>
        <!--end section-->
        <section class="section-md thanks-text">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h3 class="text-center">Thank you!</h3>
                    </div>
                    <!--end col-->
                </div>
                <!--end row-->
            </div>
            <!--end container-->
        </section>
        <!--end section-->

        <footer class="footer-area">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 text-center">
                        <p class="copyright mb-0 py-4">© 2020. Design By H∆DI</p>
                    </div>
                    <!--end col-->
                </div>
                <!--end row-->
            </div>
            <!--end container-->
        </footer>
        <!--end footer-area-->
    </div>
    <!--end main-wraper-->


    <!-- jQuery  -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="plugins/ripple/jquery.ripples.js"></script>
    <script src="plugins/counter/jquery.counterup.min.js"></script>
    <script src="plugins/counter/waypoints.min.js"></script>
    <script src="plugins/filter/isotope.pkgd.min.js"></script>
    <script src="plugins/filter/masonry.pkgd.min.js"></script>
    <script src="plugins/filter/jquery.magnific-popup.min.js"></script>
    <script src="plugins/animated/headline.js"></script>

    <!-- App js -->
    <script src="js/app.js"></script>

</body>

</html>