<?php
    if(session_id() == ''){
      session_start();
    }
    if(isset($_SESSION['reADyaiLOGp@S'])){
        header("location: ../index.php");
    }else{
      session_destroy();
    }    
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Login | ReadyAi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesdesign" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />

</head>

<script>

    //AJAX CODE STARTS
    function postComment() {
        // alert("it worked!");
        var request = new XMLHttpRequest();
        request.open("POST", "../controller/userAuthentication.php");
        request.onreadystatechange = function() {
            
            // Check if the request is compete and was successful
            if(this.readyState === 4 && this.status === 200) {
                // Inserting the response from server into an HTML element
                // document.getElementById("result").innerHTML = this.responseText;
                var loginResponse = this.responseText;
                if(loginResponse == "success"){
                    document.getElementById("loginStatus").innerHTML = loginResponse;
                    window.location='index.php';
                    // Please make sure you have registered and verified account (contact support for account varification).
                }else{
                    document.getElementById("loginStatus").innerHTML = loginResponse;
                    document.getElementById("loginStatus").style.visibility = "visible";
                    
                }
            }
        };
        
        // Retrieving the form data
        var myForm = document.getElementById("myLoginForm");
        var formData = new FormData(myForm);

        // Sending the request to the server
        request.send(formData);
    }

    //AJAX CODE ENDS

</script>

<body class="bg-primary bg-pattern">
    <div class="home-btn d-none d-sm-block">
        <a href="../index.php"><i class="mdi mdi-home-variant h2 text-white"></i></a>
    </div>

    <div class="account-pages my-5 pt-sm-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-center mb-5">
                        <a href="index.php" class="logo"><img src="assets/images/logo-light.png" height="24" alt="logo"></a>
                        <h5 class="font-size-16 text-white-50 mb-4">Welcome to ReadyAi Login</h5>
                    </div>
                </div>
            </div>
            <!-- end row -->

            <div class="row justify-content-center">
                <div class="col-xl-5 col-sm-8">
                    <div class="card">
                        <div class="card-body p-4">
                            <div class="p-2">
                                <h5 class="mb-5 text-center">Sign in to continue to ReadyAi.</h5>
                                <form id="myLoginForm" class="form-horizontal" method="POST">

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group form-group-custom mb-4">
                                                <input type="text" class="form-control" id="email" name="email" required>
                                                <label for="email">email</label>
                                            </div>

                                            <div class="form-group form-group-custom mb-4">
                                                <input type="password" class="form-control" id="password" name="password" required>
                                                <label for="password">Password</label>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input" id="customControlInline">
                                                        <label class="custom-control-label" for="customControlInline">Remember me</label>
                                                    </div>
                                                </div>
                                                <!-- <div class="col-md-6">
                                                    <div class="text-md-right mt-3 mt-md-0">
                                                        <a href="recoverpw.php" class="text-muted"><i class="mdi mdi-lock"></i> Forgot your password?</a>
                                                    </div>
                                                </div> -->
                                            </div>
                                            <div class="mt-4">
                                                <button class="btn btn-success btn-block waves-effect waves-light" type="button" onclick="postComment();" id="btnLogin" >Log In</button>
                                            </div>
                                            <div class="mt-4 text-center">
                                                <a href="signup.php" class="text-muted"><i class="mdi mdi-account-circle mr-1"></i> Create an account</a>
                                                <br>
                                                <label id="loginStatus" style="color: red; visibility: hidden;">Username and password doesn't match</label>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
    </div>
    <!-- end Account pages -->

    <!-- JAVASCRIPT -->
    <script src="assets/libs/jquery/jquery.min.js"></script>
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/metismenu/metisMenu.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>

    <script src="https://unicons.iconscout.com/release/v2.0.1/script/monochrome/bundle.js"></script>

    <script src="assets/js/app.js"></script>

</body>

</html>