<?php
    if(session_id() == ''){
      session_start();
    }
    if(isset($_SESSION['reADyaiLOGp@S'])){
        header("location: ../index.php");
    }else{
      session_destroy();
    }    
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>SignUp | ReadyAi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesdesign" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />

</head>

<script>
    //AJAX CODE STARTS
    function signUp() {
        var request = new XMLHttpRequest();
        request.open("POST", "../controller/signup.php");
        request.onreadystatechange = function() {
            
            // Check if the request is compete and was successful
            if(this.readyState === 4 && this.status === 200) {
                // Inserting the response from server into an HTML element
                // document.getElementById("result").innerHTML = this.responseText;
                var pass = document.getElementById("password");
                var rePass = document.getElementById("repassword");
                var name = document.getElementById("username");
                var email = document.getElementById("email");
                var designation = document.getElementById("designation");
                var signupStatus = document.getElementById("signupStatus");

                if(name.value == "" || email.value == "" || designation.value == "" || pass.value == "" || rePass.value == ""){
                    signupStatus.innerHTML = "Please fill in all the fields to continue";
                    signupStatus.style.visibility = "visible";
                }else{
                    if(pass.value == rePass.value){
                        var loginResponse = this.responseText;
                        if(loginResponse == "Successfully registered"){
                            signupStatus.style.color = "black";
                            signupStatus.innerHTML = loginResponse;
                            signupStatus.style.visibility = "visible";
                            window.location='login.php';
                        }else{
                            // alert("Hello! I am an alert box!!");
                            signupStatus.innerHTML = loginResponse;
                            signupStatus.style.visibility = "visible";
                        }
                    }else{
                        signupStatus.innerHTML = "Passwords don't match!";
                        signupStatus.style.visibility = "visible";
                    }
                }
            }
        };
        
        // Retrieving the form data
        var myForm = document.getElementById("mySignupForm");
        var formData = new FormData(myForm);

        // Sending the request to the server
        request.send(formData);
    }

    //AJAX CODE ENDS

</script>

<body class="bg-primary bg-pattern">
    <div class="home-btn d-none d-sm-block">
        <a href="../index.php"><i class="mdi mdi-home-variant h2 text-white"></i></a>
    </div>

    <div class="account-pages my-5 pt-sm-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-center mb-5">
                        <a href="index.php" class="logo"><img src="assets/images/logo-light.png" height="24" alt="logo"></a>
                        <h5 class="font-size-16 text-white-50 mb-4">Welcome to ReadyAi Registration</h5>
                    </div>
                </div>
            </div>
            <!-- end row -->

            <div class="row justify-content-center">
                <div class="col-xl-5 col-sm-8">
                    <div class="card">
                        <div class="card-body p-4">
                            <div class="p-2">
                                <h5 class="mb-5 text-center">Register Account to ReadyAi.</h5>
                                <form id="mySignupForm" class="form-horizontal" method="POST">

                                <!-- name="name"
                                name="designation"
                                name="email"
                                name="password"
                                name="repassword" -->

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group form-group-custom mb-4">
                                                <input type="text" class="form-control" id="username" name="name" required>
                                                <label for="name">Full Name</label>
                                            </div>
                                            <div class="form-group form-group-custom mb-4">
                                                <input type="text" class="form-control" id="designation" name="designation" required>
                                                <label for="designation">Designation</label>
                                            </div>
                                            <div class="form-group form-group-custom mb-4">
                                                <input type="email" class="form-control" id="email" name="email" required>
                                                <label for="email">Email</label>
                                            </div>
                                            <div class="form-group form-group-custom mb-4">
                                                <input type="password" class="form-control" name="password" id="password" required>
                                                <label for="password">Password</label>
                                            </div>

                                            <div class="form-group form-group-custom mb-4">
                                                <input type="password" class="form-control" id="repassword" name="repassword" required>
                                                <label for="repassword">Confirm Password</label>
                                            </div>
                                            <!-- <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input" id="term-conditionCheck">
                                                <label class="custom-control-label font-weight-normal" for="term-conditionCheck">I accept <a href="#" class="text-primary">Terms and Conditions</a></label>
                                            </div> -->
                                            <div class="mt-4">
                                                <button class="btn btn-success btn-block waves-effect waves-light" type="button" onclick="signUp();">Register</button>
                                            </div>
                                            <div class="mt-4 text-center">
                                                <a href="login.php" class="text-muted"><i class="mdi mdi-account-circle mr-1"></i> Already have account?</a>
                                                <br>
                                                <label id="signupStatus" style="color: red; visibility: hidden;">Email already registered, please try other email</label>
                                                <input type="hidden" id="tSecKey_123" name="tSecKey_123" value="t_SecKey_12345">
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
    </div>
    <!-- end Account pages -->

    <!-- JAVASCRIPT -->
    <script src="assets/libs/jquery/jquery.min.js"></script>
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/metismenu/metisMenu.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>

    <script src="https://unicons.iconscout.com/release/v2.0.1/script/monochrome/bundle.js"></script>


    <script src="assets/js/app.js"></script>

</body>

</html>