<?php
    if(session_id() == ''){
      session_start();
    }
    if(isset($_SESSION['reADyaiLOGp@S'])){
        header("location: ../index.php");
    }else{
      session_destroy();
    }    
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <title>ReadyAi Login</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" type="image/png" href="images/icons/favicon.ico" />
        <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
        <!-- <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css"> -->
        <link rel="stylesheet" type="text/css" href="css/util.css">
        <link rel="stylesheet" type="text/css" href="css/main.css">

    </head>

    

    <script>

        //AJAX CODE STARTS
        function postComment() {
            var request = new XMLHttpRequest();
            request.open("POST", "../controller/userAuthentication.php");
            request.onreadystatechange = function() {
                
                // Check if the request is compete and was successful
                if(this.readyState === 4 && this.status === 200) {
                    // Inserting the response from server into an HTML element
                    // document.getElementById("result").innerHTML = this.responseText;
                    var loginResponse = this.responseText;
                    if(loginResponse == "success"){
                        window.location='../index.php';
                    }else{
                        document.getElementById("loginStatus").style.visibility = "visible";
                        // alert("Hello! I am an alert box!!");
                    }
                }
            };
            
            // Retrieving the form data
            var myForm = document.getElementById("myLoginForm");
            var formData = new FormData(myForm);

            // Sending the request to the server
            request.send(formData);
        }

        //AJAX CODE ENDS

    </script>

    <body>

        <div class="limiter">
            <div class="container-login100">
                <div class="wrap-login100 p-t-50 p-b-90">
                    <form id="myLoginForm" class="login100-form validate-form flex-sb flex-w" method="POST">
                        <span style="text-transform: capitalize;" class="login100-form-title p-b-51">
						ReadyAi Login
					</span>


                        <div class="wrap-input100 validate-input m-b-16" data-validate="Username is required">
                            <input class="input100" id="userEmail" type="text" name="email" placeholder="Username">
                            <span class="focus-input100"></span>
                        </div>


                        <div class="wrap-input100 validate-input m-b-16" data-validate="Password is required">
                            <input class="input100" id="userPass" type="password" name="password" placeholder="Password">
                            <span class="focus-input100"></span>
                        </div>

                        <div class="flex-sb-m w-full p-t-3 p-b-24">
                            <div class="contact100-form-checkbox">
                                <input class="input-checkbox100" id="ckb1" type="checkbox" name="remember-me">
                                <label class="label-checkbox100" for="ckb1">
								Remember me
							</label>
                            </div>

                            <!-- <div>
                                <a href="#" class="txt1">
								Forgot password?
							    </a>
                            </div> -->
                        </div>

                        <div>
                            New user?<a href="signup.php" class="txt1"> Signup</a>
                            <label id="loginStatus" style="color: red; visibility: hidden;">Username/password doesn't match</label>
                        </div>

                        <div class="container-login100-form-btn m-t-17">
                            <button type="button" id="btnLogin" onclick="postComment();" class="login100-form-btn">
							Login
						</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <script src="jquery/jquery-3.2.1.min.js"></script>
        <script src="js/main.js"></script>

    </body>

    </html>